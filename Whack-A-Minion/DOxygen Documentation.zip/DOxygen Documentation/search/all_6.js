var searchData=
[
  ['play',['play',['../class_main_window.html#a4f035b25b6181829a9275155e3ca9bbd',1,'MainWindow']]]
];
