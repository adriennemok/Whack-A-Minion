var searchData=
[
  ['score',['score',['../classscore.html#a2ea005f61abba30a04d85e926cbf7a99',1,'score']]]
];
