var searchData=
[
  ['game',['Game',['../class_game.html#ae3c64a8dd73de0a99849db8ec0e9a86c',1,'Game']]],
  ['get_5fscore',['get_score',['../classscore.html#af3db6965508ac71ac33ffafd16f8c725',1,'score']]]
];
