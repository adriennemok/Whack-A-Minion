var searchData=
[
  ['raise_5fscore',['raise_score',['../classscore.html#a563ccda8cb1062f19d9ab01bc36d5e47',1,'score']]],
  ['reset_5fscore',['reset_score',['../classscore.html#a66471eb947418b1532607519257a272a',1,'score']]]
];
