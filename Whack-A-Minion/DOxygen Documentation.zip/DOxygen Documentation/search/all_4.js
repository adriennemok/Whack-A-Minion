var searchData=
[
  ['leave_5fgame',['leave_game',['../class_game.html#adc03bd7ce6c2f8c5146a3cdd83655fc4',1,'Game']]]
];
