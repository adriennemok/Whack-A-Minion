var searchData=
[
  ['score',['score',['../classscore.html',1,'']]]
];
